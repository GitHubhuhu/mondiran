${project.name}
${project.version}.${build.number}
Copyright © ${project.inceptionYear} ${project.organization.name}

Place any JDBC driver JARs in this directory. They will automatically be added
to the classpath.