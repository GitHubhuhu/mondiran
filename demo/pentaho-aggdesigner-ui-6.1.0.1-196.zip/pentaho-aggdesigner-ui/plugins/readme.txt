Place any extensions to the AggDesigner in this directory.  
Please see the Plugin Developers Guide for more information 
on extending AggDesigner.

http://wiki.pentaho.com/AggDesigner/Plugin-Developers-Guide
